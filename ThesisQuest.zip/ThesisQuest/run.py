import pygame

if __name__ == "__main__":
    pygame.init()
    screen = pygame.display.set_mode((500, 500))
    
    pygame.display.set_caption("Thesis Quest")
    
    iconpic = pygame.image.load('menu/icon.png')
    pygame.display.set_icon(iconpic)

    
    
    from menu.main_menu import MainMenu
    main_menu = MainMenu(screen)
    main_menu.run()
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
