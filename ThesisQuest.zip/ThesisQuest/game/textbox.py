import pygame
import pygame.gfxdraw


class Textbox(object): # alsó textbox 
    def __init__(self, x, y, width, height, screen):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.screen = screen
        self.tbox = pygame.image.load("game/textbox.png") 
        

    def Draw(self, screen):
        self.screen.blit(self.tbox, (self.x, self.y))
