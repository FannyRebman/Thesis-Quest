import pygame
import pygame.gfxdraw

class HitBox: # was npc class
    
    
    def __init__(self, player, screen, collide): # playeren + itemen kívül minden más hitbox

        self.player = player
        self.collide = collide
        self.screen = screen
        #self.hitbox = pygame.Rect(x, y, width, height)
        self.hitboxes = [pygame.Rect(82, 72, 32, 14), #0
                       pygame.Rect(10, 72, 32, 14), #1
                       pygame.Rect(10, 122, 32, 14), #2
                       pygame.Rect(82, 122, 32, 14), #3
                       pygame.Rect(357, 65, 32, 14), #4
                       pygame.Rect(357, 118, 32, 14), #5
                       pygame.Rect(437, 118, 32, 14), #6
                       pygame.Rect(437, 65, 32, 14), #7
                       pygame.Rect(67, 42, 32, 14), #8
                       pygame.Rect(388, 35, 32, 14), #9
                       pygame.Rect(18, 258, 32, 14), #10
                       pygame.Rect(18, 307, 32, 14), #11
                       pygame.Rect(110, 258, 32, 14), #12
                       pygame.Rect(110, 307, 32, 14), #13
                       pygame.Rect(390, 228, 32, 14), #14
                       pygame.Rect(355, 263, 32, 14), #15
                       pygame.Rect(355, 311, 32, 14), #16
                       pygame.Rect(437, 263, 32, 14), #17
                       pygame.Rect(437, 311, 32, 14), #18
                       pygame.Rect(67, 229, 32, 14), #19
                       pygame.Rect(175, 0, 15, 100), #20
                       pygame.Rect(292, 0, 15, 100), #21
                       pygame.Rect(175, 172, 15, 120), #22
                       pygame.Rect(292, 172, 15, 120), #23
                       pygame.Rect(0, 172, 190, 60), #24
                       pygame.Rect(292, 172, 210, 60), #25 
                       pygame.Rect(0, 30, 500, 10), #26
                       pygame.Rect(407, 50, 15, 18), #27
                       pygame.Rect(308, 37, 15, 18)] #28

    def Collide(self):
        for item in self.hitboxes:
            if self.player.hitbox.colliderect(item):
                self.collide = True
           
                
    
    def Moving(self):

        
        
        keys = pygame.key.get_pressed()
        
        if self.collide == True:
            print(self.collide)                               
            

            if keys[pygame.K_LEFT] and self.player.x > self.player.vel :
                self.player.x = self.player.x + self.player.vel
                

                self.player.left = True
                self.player.right = False
                self.player.up = False
                self.player.down = False
                self.player.standing = False
                
                self.collide = False
                
                
            elif keys[pygame.K_RIGHT]  and self.player.x < (500 - self.player.width) - self.player.vel: #w_width
                self.player.x = self.player.x - self.player.vel
                
                self.player.left = False
                self.player.right = True
                self.player.up = False
                self.player.down = False
                self.player.standing = False

                self.collide = False
                
            elif keys[pygame.K_UP] and self.player.y > self.player.vel :
                self.player.y = self.player.y + self.player.vel
                
                self.player.left = False
                self.player.right = False
                self.player.up = True
                self.player.down = False
                self.player.standing = False

                self.collide = False
                
            elif keys[pygame.K_DOWN] and self.player.y < (350 - self.player.height) - self.player.vel: #w_height
                self.player.y = self.player.y - self.player.vel
                
                self.player.left = False
                self.player.right = False
                self.player.up = False
                self.player.down = True
                self.player.standing = False

                self.collide = False
            
            else:
                self.collide = False
                self.player.standing = True
                self.player.walking = 0
       
            
        else:
            #self.collide = False
            print(self.collide)
            
            if keys[pygame.K_LEFT] and self.player.x > self.player.vel :
                #if keys[pygame.K_LEFT] and self.collide == False:
                self.player.x -= self.player.vel
            
                self.player.left = True
                self.player.right = False
                self.player.up = False
                self.player.down = False
                self.player.standing = False

            elif keys[pygame.K_RIGHT]  and self.player.x < (500 - self.player.width) - self.player.vel: #w_width
                self.player.x += self.player.vel
            
                self.player.left = False
                self.player.right = True
                self.player.up = False
                self.player.down = False
                self.player.standing = False
            
            elif keys[pygame.K_UP] and self.player.y > self.player.vel :
                self.player.y -= self.player.vel
            
                self.player.left = False
                self.player.right = False
                self.player.up = True
                self.player.down = False
                self.player.standing = False
            
            elif keys[pygame.K_DOWN] and self.player.y < (350 - self.player.height) - self.player.vel: #w_height
                self.player.y += self.player.vel
            
                self.player.left = False
                self.player.right = False
                self.player.up = False
                self.player.down = True
                self.player.standing = False
            
            else:
                #self.player.left = False
                #self.player.right = False
                #self.player.up = False
                #self.player.down = False
                self.player.standing = True
                self.player.walking = 0
       

    
    def Draw(self, screen):
        
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[0], 1) #1
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[1], 1) #2
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[2], 1) #3
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[3], 1) #4
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[4], 1) #5
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[5], 1) #6
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[6], 1) #7
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[7], 1) #8
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[8], 1) #9
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[9], 1) #10
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[10], 1) #11
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[11], 1) #12
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[12], 1) #13
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[13], 1) #14
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[14], 1) #15
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[15], 1) #16
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[16], 1) #17
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[17], 1) #18
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[18], 1) #19
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[19], 1) #20

        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[20], 1) #21
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[21], 1) #22
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[22], 1) #23
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[23], 1) #24
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[24], 1) #25
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[25], 1) #26

        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[26], 1) #27
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[27], 1) #28
        pygame.draw.rect(self.screen, (255,0,0), self.hitboxes[28], 1) #29
