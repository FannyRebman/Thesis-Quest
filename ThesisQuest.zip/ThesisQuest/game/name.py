from game.game import Game # játék
import pygame
import pygame.gfxdraw
import pygame.font
import sys

pygame.font.init()



class InputBox:

    def __init__(self, x, y, w, h, font, color_active, color_inactive, screen):
        self.textbox = pygame.Rect(x, y, w, h)
        self.font = font
        self.color_active = color_active
        self.color_inactive = color_inactive
        self.screen = screen
        self.color = self.color_inactive
        self.text = ""
        self.txt_surface = self.font.render(self.text, True, (0,0,0))
        self.active = False
        

    def Handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            
            if self.textbox.collidepoint(event.pos):
                
                self.active = not self.active
            else:
                self.active = False
            
            self.color = self.color_active if self.active else self.color_inactive
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                else:
                    self.text += event.unicode
                if len(self.text) > 8:
                    self.text = self.text[:-1]
                
                self.txt_surface = self.font.render(self.text, True, (0, 0, 0))
                
        
        

    def Draw(self,screen):
        
        self.screen.blit(self.txt_surface, (self.textbox.x+10, self.textbox.y+10))
        pygame.draw.rect(self.screen, self.color, self.textbox, 4)

        


class Main:
    def __init__(self, screen):
        self.screen = screen
        self.width = 500
        self.height = 500
        self.color_inactive = (158, 218, 210)
        self.color_active = (115, 202, 191)
        self.font = pygame.font.Font('font/wash_your_hand/Wash Your Hand.ttf', 32)
        self.bg = pygame.image.load("menu/main_menu_bg.png")
        self.title = pygame.image.load("game/name.png")
        self.start_button = pygame.image.load("menu/button_start.png")
        self.button_s = pygame.Rect(self.width/2 - 100/2, self.height/2 + 50, 100, 50)
        
        self.input_box = InputBox(self.width/2 - 150/2, self.height/2 - 60, 150, 50, self.font, self.color_active, self.color_inactive, self.screen)
        
        
    def run(self):
        clock = pygame.time.Clock()
        

        run = True

        while run:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False


                self.input_box.Handle_event(event)
                
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if self.button_s.collidepoint(event.pos):
                        if self.input_box.text != "":
                            game = Game(self.screen, self.input_box.text)
                            game.run()
            
            

            
            self.Draw()
            
            clock.tick(30)

        pygame.display.quit()
        pygame.quit()
        exit()

    def Draw(self):
        self.screen.blit(self.bg, (0,0))
        self.screen.blit(self.title, (self.width / 2 - 400 / 2 , 50))
        self.screen.blit(self.start_button, (self.button_s[0],self.button_s[1]))

        self.input_box.Draw(self.screen)
        
        pygame.display.update()
        
