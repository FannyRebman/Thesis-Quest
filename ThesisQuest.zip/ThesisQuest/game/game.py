from npc.npc1 import NPC1
from npc.npc2 import NPC2
from npc.npc3 import NPC3
from npc.npc4 import NPC4
from npc.npc5 import NPC5
from player.player_class import Player
from game.hitbox import HitBox
from game.textbox import Textbox
import pygame
import pygame.gfxdraw
import pygame.font
import sys


pygame.font.init()

        


class Game:
    def __init__(self,screen, text):
        self.width = 500
        self.height = 500
        self.bg = pygame.image.load("game/background.png")
        self.screen = screen
        self.font = pygame.font.Font('font/press_start_2p/PressStart2P.ttf', 14)
        self.clock = pygame.time.Clock()
        self.collide = False
        
        self.score = 0
        self.name = text
        
        self.win = False
        
        
        # class inicializálás
        self.player = Player(self.width/2 - 15, 350 - 32 - 5, 32, 32) # x y width height
        self.hitbox = HitBox(self.player, self.screen, self.collide)
        self.textbox = Textbox(0, 350, 500, 150, self.screen)
        self.npc1 = NPC1 (168, 316, 25, 32, self.font, self.player, self.screen)
        self.npc2 = NPC2 (293, 275, 25, 32, self.font, self.player, self.screen, self.npc1)
        self.npc3 = NPC3 (293, 141, 25, 32, self.font, self.player, self.screen, self.npc2)
        self.npc4 = NPC4 (151, 88, 25, 32, self.font, self.player, self.screen, self.npc3)
        self.npc5 = NPC5 (223, 31, 25, 32, self.font, self.player, self.screen, self.npc3)
        
        
    def run(self):
        
        
        run = True
        
        while run:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.Write()
                    run = False
            
            self.clock.tick(60)
                  
            self.Draw()
            self.npc1.Quest()
            self.npc2.Quest()
            self.npc3.Quest()
            self.npc4.Quest()
            self.npc5.Quest()
            self.Score()
            self.hitbox.Collide()
            self.hitbox.Moving()
            self.Win()
            
            
            
        pygame.display.quit()
        pygame.quit()
        exit()

    def Draw(self):
        self.screen.blit(self.bg, (0, 0))
        self.player.Draw(self.screen)
        #self.hitbox.Draw(self.screen)
        self.textbox.Draw(self.screen)

        self.npc1.Draw(self.screen)
        self.npc2.Draw(self.screen)
        self.npc3.Draw(self.screen)
        self.npc4.Draw(self.screen)
        self.npc5.Draw(self.screen)
        
        pygame.display.update()

    def Score(self): # a self.score += 1 re kvázi örökre pörgeti a számokat
        if self.npc1.done == True:
            self.score = 1
            #print(self.score)
            if self.npc2.done == True:
                self.score = 2
                #print(self.score)
                if self.npc3.done == True:
                    self.score = 3
                    #print(self.score)
                    if self.npc4.done == True:
                        self.score = 4
                        #print(self.score)
                        if self.npc5.done == True:
                            self.score = 5
                            self.win = True
                            # print(self.score)
    def Win(self):
        if self.win == True:
            
            self.Write()

            from game.gg import GG
            gg = GG(self.screen, self.score, self.name)
            gg.run()
            
            pygame.display.update
            
        return self.score
    
    def Write(self):
        with open ('game/scoreboard.txt', 'a') as f:
            f.write(str(self.score) + ';' + self.name + "\n")
    
        
