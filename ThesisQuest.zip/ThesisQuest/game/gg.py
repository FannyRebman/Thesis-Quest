
import pygame
import pygame.gfxdraw
import sys



pygame.init()

class GG():

    def __init__(self, screen, score, name):
        
        self.screen = screen
        self.width = 500
        self.height = 500
        self.title = pygame.image.load('game/won.png')
        self.button = pygame.image.load("menu/button_exit.png")
        self.b_hitbox = pygame.Rect(self.width/2 - 100/2, 400, 100, 50) 
        self.score = score
        self.name = name
        self.bg = pygame.image.load("menu/main_menu_bg.png")
        
        

    def run(self):
        run = True

        while run:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.Write()
                    run = False

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if self.b_hitbox.collidepoint(event.pos):
                        run = False
                        
                    

            
            self.Draw()

        
        pygame.display.quit()    
        pygame.quit()
        exit()
            
    def Draw(self):
        self.screen.blit(self.bg, (0, 0))
        self.screen.blit(self.title, (self.width/2 - 200, 50))
        self.screen.blit(self.button, (self.b_hitbox[0], self.b_hitbox[1]))

        pygame.display.update()
        
    def Write(self):
        with open ('game/scoreboard.txt', 'a') as f:
            f.write(str(self.score) + ';' + self.name + "\n")
