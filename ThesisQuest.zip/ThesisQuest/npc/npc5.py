import pygame
import pygame.gfxdraw
import pygame.font



class NPC5(object): # Teacher
    def __init__(self, x, y, width, height, font , player, screen, npc4):
        self.x = x
        self.y = y
        self.screen = screen
        self.tb_x = 20 # textbox x
        self.tb_y = 370 # textbox y
        self.width = width
        self.height = height
        self.font = font
        self.activeline = ""
        self.player = player
        self.npc_count = 0
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height) # hitbox: x y w h
        self.lines = [self.font.render('Oh, your Thesis!', True, (0, 0, 0)),
                      self.font.render('You should hand in your thesis', True, (0, 0, 0))]
        self.active = False
        self.done = False # nincs kész a küldetés
        self.npc4 = npc4
        

    def Quest(self):
        if self.npc4.done == True:
            self.active = True
            if self.active == True: 
                self.activeline = self.lines[0] 
                if self.player.hitbox.colliderect(self.hitbox):
                    self.done = True
                    self.active = False
        else:
            self.activeline = self.lines[1]
            
                
          

        pygame.display.update()      
                
    def Draw(self, screen):
        #pygame.draw.rect(self.screen, (255,0,0), self.hitbox, 1)
        if self.player.hitbox.colliderect(self.hitbox):
                    self.screen.blit(self.activeline, (self.tb_x, self.tb_y))

