import pygame
import pygame.gfxdraw
import pygame.font

#pygame.font.init()

class NPC1(object): # Lecso
    def __init__(self, x, y, width, height, font , player, screen):
        self.x = x
        self.y = y
        self.screen = screen
        self.tb_x = 20 # textbox x
        self.tb_y = 370 # textbox y
        self.width = width
        self.height = height
        self.font = font
        self.activeline = ""
        self.player = player
        self.npc_count = 0
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height) # hitbox: x y w h
        self.lines = [self.font.render('I forgot the screen', True, (0, 0, 0)),
                      self.font.render('You are nice, Mo!', True, (0, 0, 0))]
        self.item = pygame.Rect(18, 306, 24, 18) # hitbox: x y w h
        self.itemline = self.font.render("Can't be switched off", True, (0, 0, 0))
        self.active = True
        self.itemactive = False # akkor lesz true ha a npc_count >=1 
        self.done = False # nincs kész a küldetés
        self.itemfound = False # meg van e találva az item
        

    def Quest(self):
        if self.active == True: # ha a quest aktív toggled
            self.activeline = self.lines[0] # akkor az activeline a quest line
            if self.player.hitbox.colliderect(self.hitbox): # ha collide ol az npc vel
               
               self.npc_count += 1 # számolja hányszor beszét az npc vel
            if self.npc_count >= 1: # ha legalább egyszer beszét vele
                self.itemactive = True # az item megtalálható a questhez
            if self.itemactive == True: # ha megtalálható az item
                if self.player.hitbox.colliderect(self.item): # és ha collideol az itemmel
                    self.screen.blit(self.itemline, (self.tb_x, self.tb_y)) # kiírj az itemlinet
                    #self.itemcount += 1 # növeli egyel hányszor találta meg az itemet
                    self.itemfound = True # vagy alapból ez egynek számít már...
            if self.itemfound == True: # ha megvan az item
                self.activeline = self.lines[1] # az aktivline a megvan az item line lesz
                self.npc_count = 0
                if self.player.hitbox.colliderect(self.hitbox): # és ha megvan az item és collideol az npc vel
                    
                    self.done = True
                    self.npc_count += 1
                    self.active = False
         
        else:
            self.activeline = self.lines[1]
            #if self.player.hitbox.colliderect(self.hitbox): # ha collide ol az npc vel
                #self.screen.blit(self.activeline, (self.tb_x, self.tb_y))
                
          

        pygame.display.update()      
                
    def Draw(self, screen):
        #pygame.draw.rect(self.screen, (255,0,0), self.item, 1)
        #pygame.draw.rect(self.screen, (255,0,0), self.hitbox, 1)
        if self.player.hitbox.colliderect(self.hitbox):
            self.screen.blit(self.activeline, (self.tb_x, self.tb_y))


