import pygame
import pygame.gfxdraw
import pygame.font


class NPC2(object): # Ádám
    def __init__(self, x, y, width, height, font , player, screen, npc1):
        self.x = x
        self.y = y
        self.screen = screen
        self.tb_x = 20 # textbox x
        self.tb_y = 370 # textbox y
        self.width = width
        self.height = height
        self.font = font
        self.activeline = ""
        self.player = player
        self.npc_count = 0
        #self.item_count = 0
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height) # hitbox: x y w h
        self.lines = [self.font.render("I've lost my baglyos füzet", True, (0, 0, 0)),
                      self.font.render('Thanks, now get lost', True, (0, 0, 0)),
                      self.font.render('Bagoly!', True, (0, 0, 0))]
        self.item = pygame.Rect(359, 263, 15, 12) # hitbox: x y w h
        self.itemline = self.font.render("Baglyos füzet", True, (0, 0, 0))
        self.active = False
        self.itemactive = False # akkor lesz true ha a npc_count >=1 
        self.done = False # nincs kész a küldetés
        self.itemfound = False # meg van e találva az item
        self.npc1 = npc1
        
        

    def Quest(self):
        if self.npc1.done == True:
            self.active = True
            if self.active == True: 
                self.activeline = self.lines[0] 
                if self.player.hitbox.colliderect(self.hitbox): 
                   #self.screen.blit(self.activeline, (self.tb_x, self.tb_y)) 
                   self.npc_count += 1 
                if self.npc_count >= 1: 
                    self.itemactive = True 
                if self.itemactive == True: 
                    if self.player.hitbox.colliderect(self.item): 
                        self.screen.blit(self.itemline, (self.tb_x, self.tb_y)) 
                        self.itemfound = True 
                if self.itemfound == True: 
                    self.activeline = self.lines[1] 
                    self.npc_count = 0
                    if self.player.hitbox.colliderect(self.hitbox):
                        #self.screen.blit(self.activeline, (self.tb_x, self.tb_y))
                        self.done = True
                        self.npc_count += 1
                        self.active = False
             
            else:
                self.activeline = self.lines[2]
                #if self.player.hitbox.colliderect(self.hitbox):
                    #self.screen.blit(self.activeline, (self.tb_x, self.tb_y))
        else:
            self.activeline = self.lines[2]
            #if self.player.hitbox.colliderect(self.hitbox):
                    #self.screen.blit(self.activeline, (self.tb_x, self.tb_y))
                
            
                
          

        pygame.display.update()      
                
    def Draw(self, screen):
        #pygame.draw.rect(self.screen, (255,0,0), self.item, 1)
        #pygame.draw.rect(self.screen, (255,0,0), self.hitbox, 1)
        if self.player.hitbox.colliderect(self.hitbox):
            self.screen.blit(self.activeline, (self.tb_x, self.tb_y))
