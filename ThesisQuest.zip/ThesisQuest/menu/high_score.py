
import pygame
import pygame.gfxdraw
import pygame.font
import sys

pygame.font.init()


class HighScore():
    def __init__(self,screen):
        self.screen = screen
        self.width = 500
        self.height = 500
        self.font =  pygame.font.Font('font/wash_your_hand/Wash Your Hand.ttf', 32)
        self.title = pygame.image.load("menu/score.png")
        self.bg = pygame.image.load("menu/main_menu_bg.png")
        self.top = []
        
        self.elso_pont = ''
        self.e_pont = self.font.render(self.elso_pont, True, (0,0,0))
        self.elso_nev = ''
        self.e_nev = self.font.render(self.elso_nev, True, (0,0,0))
        
        self.masodik_pont = ''
        self.m_pont = self.font.render(self.masodik_pont, True, (0,0,0))
        self.masodik_nev = ''
        self.m_nev = self.font.render(self.masodik_nev, True, (0,0,0))

        self.harmadik_pont = ''
        self.h_pont = self.font.render(self.harmadik_pont, True, (0,0,0))
        self.harmadik_nev = ''
        self.h_nev = self.font.render(self.harmadik_nev, True, (0,0,0))
   

    def run(self):
        run = True

        while run:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False

                
                    
            self.Read()        
            self.Draw()
            
        pygame.display.quit()
        pygame.quit()
        exit()
     
                    
    def Draw(self):
        self.screen.blit(self.bg, (0,0))
        self.screen.blit(self.title, (self.width / 2 - 400 / 2, 50))
        
        self.screen.blit(self.e_nev, (125-40, 210))
        self.screen.blit(self.e_pont, (375-40, 210))
        
        self.screen.blit(self.m_nev,  (125-40, 280))
        self.screen.blit(self.m_pont, (375-40, 280))
        
        self.screen.blit(self.h_nev,  (125-40, 350))
        self.screen.blit(self.h_pont, (375-40, 350))

        
        
        pygame.display.update()
        


    def Read(self):
        with open('game/scoreboard.txt', 'r', encoding = 'utf-8-sig') as f:
            matrix = [sor.strip('\n').split(';') for sor in f]

        self.top = sorted(matrix, reverse=True)

        if len(matrix) >= 3:
            self.elso_pont = self.top[0][0]
            self.elso_nev  = self.top[0][1]
            
            self.masodik_pont = self.top[1][0]
            self.masodik_nev = self.top[1][1]
            
            self.harmadik_pont = self.top[2][0]
            self.harmadik_nev = self.top[2][1]
            
        elif len(matrix) >= 2:
            self.elso_pont = self.top[0][0]
            self.elso_nev  = self.top[0][1]
            
            self.masodik_pont = self.top[1][0]
            self.masodik_nev = self.top[1][1]
            
            self.harmadik_pont = ''
            self.harmadik_nev = ''
        elif len(matrix) >= 1:
            self.elso_pont = self.top[0][0]
            self.elso_nev  = self.top[0][1]
            
            self.masodik_pont = ''
            self.masodik_nev = ''
            
            self.harmadik_pont = ''
            self.harmadik_nev = ''
        else:
            self.elso_pont = ''
            self.elso_nev  = ''
            
            self.masodik_pont = ''
            self.masodik_nev = ''
            
            self.harmadik_pont = ''
            self.harmadik_nev = ''
            
        self.e_pont = self.font.render(self.elso_pont, True, (0,0,0))    
        self.e_nev = self.font.render(self.elso_nev, True, (0,0,0))             
        self.m_pont = self.font.render(self.masodik_pont, True, (0,0,0))    
        self.m_nev = self.font.render(self.masodik_nev, True, (0,0,0))
        self.h_pont = self.font.render(self.harmadik_pont, True, (0,0,0))
        self.h_nev = self.font.render(self.harmadik_nev, True, (0,0,0))
        
        
    
