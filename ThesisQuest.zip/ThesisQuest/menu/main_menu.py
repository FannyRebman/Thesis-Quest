from menu.high_score import HighScore
from game.name import Main
import pygame
import pygame.gfxdraw
import os
import sys


class MainMenu:
    def __init__(self,screen):

        self.width = 500
        self.height = 500
        self.title = pygame.image.load("menu/title.png")
        self.start_button = pygame.image.load("menu/button_start.png")
        self.hs_button = pygame.image.load("menu/button_hs.png")
        self.exit_button = pygame.image.load("menu/button_exit.png")
        self.b_width = 100 # b = button
        self.b_height = 50
        self.bg = pygame.image.load("menu/main_menu_bg.png")
        self.screen = screen
        # x = ablak szélességének fele - a go szélességének fele (középen) y = szintén közép, w, h 100x50
        self.button_s = pygame.Rect(self.width/2 - self.b_width/2, self.height/2 - self.b_height/2, self.b_width, self.b_height)
        self.button_hs = pygame.Rect(self.width/2 - self.b_width/2, self.button_s[1] + 65, self.b_width, self.b_height)
        self.button_e = pygame.Rect(self.width/2 - self.b_width/2, self.button_hs[1] + 65, self.b_width, self.b_height)

    
    def run(self):
        run = True

        while run:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                    
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.button_s.collidepoint(event.pos):
                    name = Main(self.screen)
                    name.run()

                elif self.button_hs.collidepoint(event.pos):
                    hs = HighScore(self.screen)
                    hs.run()

                elif self.button_e.collidepoint(event.pos):
                    run = False
                    
                


            self.Draw()

        pygame.display.quit()
        pygame.quit()
        exit()

    def Draw(self):
        self.screen.blit(self.bg, (0,0))
        self.screen.blit(self.title, (self.width / 2 - 400 / 2, 100))
        self.screen.blit(self.start_button, (self.button_s[0],self.button_s[1]))
        self.screen.blit(self.hs_button, (self.button_hs[0],self.button_hs[1]))
        self.screen.blit(self.exit_button, (self.button_e[0],self.button_e[1]))
        
        pygame.display.update()




    
