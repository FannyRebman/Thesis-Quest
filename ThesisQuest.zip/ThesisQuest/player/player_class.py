import pygame
import pygame.gfxdraw

class Player(object):
    def __init__(self,x,y,width,height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 2
        self.left = False
        self.right = False
        self.up = False
        self.down = False
        self.walking = 0
        self.standing = True
        self.hitbox = pygame.Rect(self.x + 5, self.y + 20, 15, 10) # x y  width height (a hitbox direkt a lehető legkisebb)

        self.WalkLeft = [pygame.image.load('player/L_STAND.png'), pygame.image.load('player/L_WALK1.png'), pygame.image.load('player/L_WALK2.png')]
        self.WalkRight = [pygame.image.load('player/R_STAND.png'), pygame.image.load('player/R_WALK1.png'), pygame.image.load('player/R_WALK2.png')]
        self.WalkUp = [pygame.image.load('player/B_STAND.png'), pygame.image.load('player/B_WALK1.png'), pygame.image.load('player/B_WALK2.png')]
        self.WalkDown = [pygame.image.load('player/U_STAND.png'), pygame.image.load('player/U_WALK1.png'), pygame.image.load('player/U_WALK2.png')]
        
        

    def Draw(self, screen):
        if self.walking + 1 >= 9:
            self.walking = 0

    
        if not(self.standing) : # ha nincs állásban a karakter (megy)
            if self.left: # bal
                screen.blit(self.WalkLeft[self.walking // 3], (self.x,self.y))# leanimálva megy a képeket egymásutánrakva x és y on
                self.walking += 1
            elif self.right: # jobb
                screen.blit(self.WalkRight[self.walking // 3], (self.x,self.y))# leanimálva megy a képeket egymásutánrakva x és y on
                self.walking +=1
            elif self.up: # fel
                screen.blit(self.WalkUp[self.walking // 3], (self.x, self.y))# leanimálva megy a képeket egymásutánrakva x és y on
                self.walking += 1
            elif self.down: # le
                screen.blit(self.WalkDown[self.walking // 3], (self.x, self.y)) # leanimálva megy a képeket egymásutánrakva x és y on
                self.walking += 1
        else: # áll - x y on a bal jobb fel le irányokba az adott irányú Walk'stb' listán belül a [0]s kép az egyhelyben állás, azt fogja mutatni, abba az irányba néz amerre ment
            if self.left:
                screen.blit(self.WalkLeft[0], (self.x, self.y))
            elif self.right:
                screen.blit(self.WalkRight[0], (self.x, self.y))
            elif self.up:
                screen.blit(self.WalkUp[0], (self.x, self.y))
            elif self.down:
                screen.blit(self.WalkDown[0], (self.x, self.y))
            else:
                screen.blit(self.WalkDown[0], (self.x, self.y))# saját, hogyha egyik fele se van akkor szembe !!! enélkül csak akkor jelenne meg a karakter ha mozgatnánk valamerre => enélkül amikor elindul a program, nem jelenik meg a karakter amíg nem mozgattuk valamerre

        self.hitbox = pygame.Rect(self.x + 5 , self.y + 20, 15, 10) #!
        #pygame.draw.rect(screen, (255,0,0), self.hitbox, 1) #!
